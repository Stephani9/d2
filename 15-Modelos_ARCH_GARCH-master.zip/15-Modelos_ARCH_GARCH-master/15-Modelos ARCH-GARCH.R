                    #Aula 14 - Quebra Estrural e Bolhas
remove.packages("readxl")
install.packages("readxl", dependencies = T)
install.packages("strucchange")
remove.packages("aTSA")
install.packages("aTSA", dependencies = T)

library(strucchange)
library(readxl)
library(aTSA)
library(tseries)
library("urca") 


BITCOIN <- na.omit(read_excel("C:/Econometria/Bitcoin.xls"))

Bitcoin <-  ts(BITCOIN$Close, start = 2014, frequency = 365)

plot(Bitcoin)

#Verificar se a Série é Estacionária

#Criar FAC  e FACP

acf(BITCOIN$Close,lend=2, lwd=5,col="darkblue",main= "Função Autocorrelação - FAC")              #Melhorando aspecto da FAC
axis(1,tck = 1, col = "lightgrey", lty = "dotted")

pacf(BITCOIN$Close,lend=60, lwd=5,col="darkblue",main= "Função Autocorrelação Parcial - FACP")   #Melhorando aspecto da PAC
axis(1,tck = 1, col = "lightgrey", lty = "dotted")

#Teste ADF
ur.df(Bitcoin, "none", lags = 1)

#Teste Philips-Perron
pp.test(Bitcoin)

#Teste KPSS
kpss.test(Bitcoin)

#Se não for estacionária, diferenciar a série

IntOrdem1 <- diff(BITCOIN$Close)
IntegradaOrdem1 <- ts(IntOrdem1, start = 2014, frequency = 365)
plot(IntegradaOrdem1)

#Verificar se a Série se tornou Estacionária

#FAC e FACP

acf(IntOrdem1,lend=2, lwd=5,col="darkblue",main= "Função Autocorrelação - FAC",lag=10)              #Melhorando aspecto da FAC
axis(1,tck = 1, col = "lightgrey", lty = "dotted")

pacf(IntOrdem1,lend=60, lwd=5,col="darkblue",main= "Função Autocorrelação Parcial - FACP",lag=10)   #Melhorando aspecto da PAC
axis(1,tck = 1, col = "lightgrey", lty = "dotted")

#Teste ADF
ur.df(IntegradaOrdem1, "none", lags = 1)

#Teste Philips-Perron
pp.test(IntegradaOrdem1)

#Teste KPSS
kpss.test(IntegradaOrdem1)


#Verificar quais ordens são as melhores

#Estimando Regressões e Tabelando Resultados - Exemplo

arima010 <- arima(IntegradaOrdem1, order = c(10,1,6))

arima110 <- arima(IntegradaOrdem1, order = c(1,1,0))
arima111 <- arima(IntegradaOrdem1, order = c(1,1,1))
arima112 <- arima(IntegradaOrdem1, order = c(1,1,2))
arima113 <- arima(IntegradaOrdem1, order = c(1,1,3))
arima114 <- arima(IntegradaOrdem1, order = c(1,1,4))
arima115 <- arima(IntegradaOrdem1, order = c(1,1,5))
arima116 <- arima(IntegradaOrdem1, order = c(1,1,6))
arima117 <- arima(IntegradaOrdem1, order = c(1,1,7))
arima118 <- arima(IntegradaOrdem1, order = c(1,1,8))
arima119 <- arima(IntegradaOrdem1, order = c(1,1,9))
arima1110 <- arima(IntegradaOrdem1, order = c(1,1,10))

arima210 <- arima(IntegradaOrdem1, order = c(2,1,0))
arima211 <- arima(IntegradaOrdem1, order = c(2,1,1))
arima212 <- arima(IntegradaOrdem1, order = c(2,1,2))
arima213 <- arima(IntegradaOrdem1, order = c(2,1,3))
arima214 <- arima(IntegradaOrdem1, order = c(2,1,4))
arima215 <- arima(IntegradaOrdem1, order = c(2,1,5))
arima216 <- arima(IntegradaOrdem1, order = c(2,1,6))
arima217 <- arima(IntegradaOrdem1, order = c(2,1,7))
arima218 <- arima(IntegradaOrdem1, order = c(2,1,8))
arima219 <- arima(IntegradaOrdem1, order = c(2,1,9))
arima2110 <- arima(IntegradaOrdem1, order = c(2,1,10))

arima310 <- arima(IntegradaOrdem1, order = c(3,1,0))
arima311 <- arima(IntegradaOrdem1, order = c(3,1,1))
arima312 <- arima(IntegradaOrdem1, order = c(3,1,2))
arima313 <- arima(IntegradaOrdem1, order = c(3,1,3))
arima314 <- arima(IntegradaOrdem1, order = c(3,1,4))
arima315 <- arima(IntegradaOrdem1, order = c(3,1,5))
arima316 <- arima(IntegradaOrdem1, order = c(3,1,6))
arima317<- arima(IntegradaOrdem1, order = c(3,1,7))
arima318 <- arima(IntegradaOrdem1, order = c(3,1,8))
arima319 <- arima(IntegradaOrdem1, order = c(3,1,9))
arima3110 <- arima(IntegradaOrdem1, order = c(3,1,10))


arima410 <- arima(IntegradaOrdem1, order = c(4,1,0))
arima411 <- arima(IntegradaOrdem1, order = c(4,1,1))
arima412 <- arima(IntegradaOrdem1, order = c(4,1,2))
arima413 <- arima(IntegradaOrdem1, order = c(4,1,3))
arima414 <- arima(IntegradaOrdem1, order = c(4,1,4))
arima415 <- arima(IntegradaOrdem1, order = c(4,1,5))
arima416 <- arima(IntegradaOrdem1, order = c(4,1,6))
arima417 <- arima(IntegradaOrdem1, order = c(4,1,7))
arima418 <- arima(IntegradaOrdem1, order = c(4,1,8))
arima419 <- arima(IntegradaOrdem1, order = c(4,1,9))
arima4110 <- arima(IntegradaOrdem1, order = c(4,1,10))

arima510 <- arima(IntegradaOrdem1, order = c(5,1,0))
arima511 <- arima(IntegradaOrdem1, order = c(5,1,1))
arima512 <- arima(IntegradaOrdem1, order = c(5,1,2))
arima513 <- arima(IntegradaOrdem1, order = c(5,1,3))
arima514 <- arima(IntegradaOrdem1, order = c(5,1,4))
arima515 <- arima(IntegradaOrdem1, order = c(5,1,5))
arima516 <- arima(IntegradaOrdem1, order = c(5,1,6))
arima517 <- arima(IntegradaOrdem1, order = c(5,1,7))
arima518 <- arima(IntegradaOrdem1, order = c(5,1,8))
arima519 <- arima(IntegradaOrdem1, order = c(5,1,9))
arima5110 <- arima(IntegradaOrdem1, order = c(5,1,10))

arima610 <- arima(IntegradaOrdem1, order = c(6,1,0))
arima611 <- arima(IntegradaOrdem1, order = c(6,1,1))
arima612 <- arima(IntegradaOrdem1, order = c(6,1,2))
arima613 <- arima(IntegradaOrdem1, order = c(6,1,3))
arima614 <- arima(IntegradaOrdem1, order = c(6,1,4))
arima615 <- arima(IntegradaOrdem1, order = c(6,1,5))
arima616 <- arima(IntegradaOrdem1, order = c(6,1,6))
arima617 <- arima(IntegradaOrdem1, order = c(6,1,7))
arima618 <- arima(IntegradaOrdem1, order = c(6,1,8))
arima619 <- arima(IntegradaOrdem1, order = c(6,1,9))
arima6110 <- arima(IntegradaOrdem1, order = c(6,1,10))

arima710 <- arima(IntegradaOrdem1, order = c(7,1,0))
arima711 <- arima(IntegradaOrdem1, order = c(7,1,1))
arima712 <- arima(IntegradaOrdem1, order = c(7,1,2))
arima713 <- arima(IntegradaOrdem1, order = c(7,1,3))
arima714 <- arima(IntegradaOrdem1, order = c(7,1,4))
arima715 <- arima(IntegradaOrdem1, order = c(7,1,5))
arima716 <- arima(IntegradaOrdem1, order = c(7,1,6))
arima717 <- arima(IntegradaOrdem1, order = c(7,1,7))
arima718 <- arima(IntegradaOrdem1, order = c(7,1,8))
arima719 <- arima(IntegradaOrdem1, order = c(7,1,9))
arima7110 <- arima(IntegradaOrdem1, order = c(7,1,10))

arima810 <- arima(IntegradaOrdem1, order = c(8,1,0))
arima811 <- arima(IntegradaOrdem1, order = c(8,1,1))
arima812 <- arima(IntegradaOrdem1, order = c(8,1,2))
arima813 <- arima(IntegradaOrdem1, order = c(8,1,3))
arima814 <- arima(IntegradaOrdem1, order = c(8,1,4))
arima815 <- arima(IntegradaOrdem1, order = c(8,1,5))
arima816 <- arima(IntegradaOrdem1, order = c(8,1,6))
arima817 <- arima(IntegradaOrdem1, order = c(8,1,7))
arima818 <- arima(IntegradaOrdem1, order = c(8,1,8))
arima819 <- arima(IntegradaOrdem1, order = c(8,1,9))
arima8110 <- arima(IntegradaOrdem1, order = c(8,1,10))

arima910 <- arima(IntegradaOrdem1, order = c(9,1,0))
arima911 <- arima(IntegradaOrdem1, order = c(9,1,1))
arima912 <- arima(IntegradaOrdem1, order = c(9,1,2))
arima913 <- arima(IntegradaOrdem1, order = c(9,1,3))
arima914 <- arima(IntegradaOrdem1, order = c(9,1,4))
arima915 <- arima(IntegradaOrdem1, order = c(9,1,5))
arima916 <- arima(IntegradaOrdem1, order = c(9,1,6))
arima917 <- arima(IntegradaOrdem1, order = c(9,1,7))
arima918 <- arima(IntegradaOrdem1, order = c(9,1,8))
arima919 <- arima(IntegradaOrdem1, order = c(9,1,9))
arima9110 <- arima(IntegradaOrdem1, order = c(9,1,10))

arima1010 <- arima(IntegradaOrdem1, order = c(10,1,0))
arima1011 <- arima(IntegradaOrdem1, order = c(10,1,1))
arima1012 <- arima(IntegradaOrdem1, order = c(10,1,2))
arima1013 <- arima(IntegradaOrdem1, order = c(10,1,3))
arima1014 <- arima(IntegradaOrdem1, order = c(10,1,4))
arima1015 <- arima(IntegradaOrdem1, order = c(10,1,5))
arima1016 <- arima(IntegradaOrdem1, order = c(10,1,6))
arima1017 <- arima(IntegradaOrdem1, order = c(10,1,7))
arima1018 <- arima(IntegradaOrdem1, order = c(10,1,8))
arima1019 <- arima(IntegradaOrdem1, order = c(10,1,9))
arima10110 <- arima(IntegradaOrdem1, order = c(10,1,10))













MA2 <- arima(IntegradaOrdem1, order = c(0,0,2))
MA3 <- arima(var_PIB, order = c(0,0,3))
MA4 <- arima(var_PIB, order = c(0,0,4))
MA5 <- arima(var_PIB, order = c(0,0,5))
MA6 <- arima(var_PIB, order = c(0,0,6))
MA7 <- arima(var_PIB, order = c(0,0,7))
MA8 <- arima(var_PIB, order = c(0,0,8))
MA9 <- arima(var_PIB, order = c(0,0,9))

ARMA12 <- arima(var_PIB, order = c(1,0,2))
ARMA13 <- arima(var_PIB, order = c(1,0,3))
ARMA14 <- arima(var_PIB, order = c(1,0,4))
ARMA15 <- arima(var_PIB, order = c(1,0,5))
ARMA16 <- arima(var_PIB, order = c(1,0,6))
ARMA17 <- arima(var_PIB, order = c(1,0,7))
ARMA18 <- arima(var_PIB, order = c(1,0,8))
ARMA19 <- arima(var_PIB, order = c(1,0,9))

ARMA21 <- arima(var_PIB, order = c(2,0,1))
ARMA22 <- arima(var_PIB, order = c(2,0,2))
ARMA23 <- arima(var_PIB, order = c(2,0,3))
ARMA24 <- arima(var_PIB, order = c(2,0,4))
ARMA25 <- arima(var_PIB, order = c(2,0,5))
ARMA26 <- arima(var_PIB, order = c(2,0,6))
ARMA27 <- arima(var_PIB, order = c(2,0,7))
ARMA28 <- arima(var_PIB, order = c(2,0,8))
ARMA29 <- arima(var_PIB, order = c(2,0,9))

estimacoes <- list(AR1, AR2, MA1, MA2, MA3, MA4, MA5, MA6, MA7, MA8, MA9, 
                   ARMA11,ARMA12, ARMA13, ARMA14,ARMA15, ARMA16,ARMA17,ARMA18,ARMA19,
                   ARMA21,ARMA22,ARMA23,ARMA24,ARMA25,ARMA26,ARMA27,ARMA28,ARMA29)      #Cria uma lista com os estimadores
sapply(estimacoes, AIC)                 #Aplica o comando AIC na lista
sapply(estimacoes, BIC)                 #Aplica o comando BIC na lista

#Exemplo de criação de tabela com resultados - Extra
AIC <- sapply(estimacoes, AIC) 
BIC <- sapply(estimacoes, BIC)
Modelo <- c("AR1", "AR2", "MA1", "MA2", "MA3", "MA4", "MA5", "MA6", "MA7", "MA8", "MA9", "ARMA11","ARMA12", "ARMA13", "ARMA14","ARMA15", "ARMA16","ARMA17","ARMA18","ARMA19","ARMA21","ARMA22","ARMA23","ARMA24","ARMA25","ARMA26","ARMA27","ARMA28","ARMA29")

Resultados <- data.frame(Modelo, AIC, BIC)
View(Resultados)
colnames(Resultados) <- c("Modelo","AIC","BIC")

#Efetuar teste ARCH-LM para o melhor modelo

arch.test(melhor_modelo)

#Modelando a Variância

